using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public class RicochetScript : MonoBehaviour
{
    public float[] slopes;
    public float[] yIntercepts;
    public float[] normals;
    // Start is called before the first frame update
    void Start()
    {
        calculateNormals();
    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(Vector3.forward * Time.deltaTime);
        for(int i = 0; i < slopes.Length; i++)
        {
            if(checkCollision(i))
            {
                Debug.Log(i);
                Vector3 newDirection = Vector3.Reflect(transform.forward, new Vector3(1, normals[i], 0));
                transform.rotation = Quaternion.LookRotation(newDirection);
                break;
            }
        }
    }

    void calculateNormals()
    {
        for (int i = 0; i < slopes.Length; i++)
        {
            normals[i] = -1 / slopes[i];
        }
    }

    bool checkCollision(int i)
    {
        float tolorance = 0.001f;
        float y = slopes[i] * transform.position.x + yIntercepts[i];
        y = Mathf.Abs(y)- Mathf.Abs(transform.position.y);
        if(Mathf.Abs(y) < tolorance)
        {
            return true;
        }
        return false;
    }
}
